import 'package:app_ropa/app/app.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Smoke: onboarding visible', (tester) async {
    await tester.pumpWidget(const AppRopa());
    expect(find.text('Saltar'), findsOneWidget);
  });
}
