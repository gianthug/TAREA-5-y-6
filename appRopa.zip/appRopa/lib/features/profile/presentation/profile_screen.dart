import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router.dart';
import '../../../app/theme/theme_scope.dart';
import '../../../core/constants/app_constants.dart';
import '../../../data/mock/mock_data.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, this.embedded = false});

  /// Si es [true], se omite [Scaffold] para incrustar en [HomeScreen].
  final bool embedded;

  @override
  Widget build(BuildContext context) {
    final user = MockData.currentUser;
    final themeMode = ThemeScope.of(context);

    final body = SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 36,
                backgroundImage: NetworkImage(user.avatarUrl),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user.name,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      user.email,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),
          Text(
            AppConstants.settingsAppearance,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(
                value: ThemeMode.system,
                label: Text(AppConstants.themeSystem),
                icon: Icon(Icons.brightness_auto, size: 18),
              ),
              ButtonSegment(
                value: ThemeMode.light,
                label: Text(AppConstants.themeLight),
                icon: Icon(Icons.light_mode_outlined, size: 18),
              ),
              ButtonSegment(
                value: ThemeMode.dark,
                label: Text(AppConstants.themeDark),
                icon: Icon(Icons.dark_mode_outlined, size: 18),
              ),
            ],
            selected: {themeMode.value},
            onSelectionChanged: (set) {
              themeMode.value = set.first;
            },
          ),
          const SizedBox(height: 20),
          _tile(
            context,
            icon: Icons.notifications_outlined,
            title: AppConstants.notifications,
            onTap: () => _snack(context, 'Preferencias de notificación (mock).'),
          ),
          _tile(
            context,
            icon: Icons.privacy_tip_outlined,
            title: AppConstants.privacy,
            onTap: () => _snack(context, 'Centro de privacidad (mock).'),
          ),
          const SizedBox(height: 16),
          FilledButton.tonal(
            onPressed: () => context.go(AppRouter.login),
            child: const Text(AppConstants.logout),
          ),
        ],
      ),
    );

    if (embedded) return body;
    return Scaffold(
      appBar: AppBar(title: const Text(AppConstants.profileTitle)),
      body: body,
    );
  }

  void _snack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Widget _tile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
