import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../app/theme/app_text_styles.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_network_image.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../data/mock/mock_data.dart';

class DetailScreen extends StatefulWidget {
  const DetailScreen({super.key, required this.productId});

  final String productId;

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  bool _loading = false;

  Future<void> _addToCart() async {
    setState(() => _loading = true);
    await Future<void>.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    setState(() => _loading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Añadido al carrito (mock).')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final product = MockData.productById(widget.productId);
    if (product == null) {
      return Scaffold(
        appBar: AppBar(),
        body: EmptyState(
          title: 'Producto no encontrado',
          message: 'El identificador no existe en los datos mock.',
          actionLabel: 'Volver',
          onAction: () => context.pop(),
        ),
      );
    }

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 360,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: AppNetworkImage(
                url: product.imageUrl,
                fit: BoxFit.cover,
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                [
                  Text(
                    product.title,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    product.subtitle,
                    style: AppTextStyles.subtle(context),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    product.formattedPrice,
                    style: AppTextStyles.priceStyle(context, emphasize: true),
                  ),
                  const SizedBox(height: 8),
                  Chip(
                    label: Text(product.category),
                    visualDensity: VisualDensity.compact,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    AppConstants.description,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    product.description,
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  const SizedBox(height: 28),
                  AppButton(
                    label: AppConstants.addToCart,
                    icon: Icons.shopping_bag_outlined,
                    loading: _loading,
                    onPressed: _loading ? null : _addToCart,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
