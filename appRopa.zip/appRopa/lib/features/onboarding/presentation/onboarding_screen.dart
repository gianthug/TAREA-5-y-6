import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router.dart';
import '../../../app/theme/app_colors.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_network_image.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  int _index = 0;

  static const _pages = <_OnboardPage>[
    _OnboardPage(
      imageUrl:
          'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80',
      title: AppConstants.onboardingTitle1,
      body: AppConstants.onboardingBody1,
    ),
    _OnboardPage(
      imageUrl:
          'https://images.unsplash.com/photo-1513258496099-48168024aec0?auto=format&fit=crop&w=1200&q=80',
      title: AppConstants.onboardingTitle2,
      body: AppConstants.onboardingBody2,
    ),
    _OnboardPage(
      imageUrl:
          'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=80',
      title: AppConstants.onboardingTitle3,
      body: AppConstants.onboardingBody3,
    ),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _goLogin() {
    context.go(AppRouter.login);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          PageView.builder(
            controller: _controller,
            itemCount: _pages.length,
            onPageChanged: (i) => setState(() => _index = i),
            itemBuilder: (context, i) {
              final page = _pages[i];
              return Stack(
                fit: StackFit.expand,
                children: [
                  AppNetworkImage(
                    url: page.imageUrl,
                    fit: BoxFit.cover,
                  ),
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          AppColors.overlayDark,
                          Color(0xCC000000),
                        ],
                      ),
                    ),
                  ),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: _goLogin,
                              child: Text(
                                AppConstants.skip,
                                style: TextStyle(color: scheme.onPrimary),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Text(
                            page.title,
                            style: Theme.of(context).textTheme.displayLarge?.copyWith(
                                  color: scheme.onPrimary,
                                  fontSize: 32,
                                ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            page.body,
                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                  color: scheme.onPrimary.withOpacity(0.92),
                                ),
                          ),
                          const SizedBox(height: 28),
                          Row(
                            children: List.generate(
                              _pages.length,
                              (dot) => AnimatedContainer(
                                duration: const Duration(milliseconds: 250),
                                margin: const EdgeInsets.only(right: 8),
                                height: 8,
                                width: dot == _index ? 28 : 8,
                                decoration: BoxDecoration(
                                  color: dot == _index
                                      ? scheme.onPrimary
                                      : scheme.onPrimary.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),
                          Row(
                            children: [
                              Expanded(
                                child: AppButton(
                                  label: _index == _pages.length - 1
                                      ? AppConstants.getStarted
                                      : AppConstants.next,
                                  onPressed: () {
                                    if (_index < _pages.length - 1) {
                                      _controller.nextPage(
                                        duration: const Duration(milliseconds: 350),
                                        curve: Curves.easeOutCubic,
                                      );
                                    } else {
                                      _goLogin();
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _OnboardPage {
  const _OnboardPage({
    required this.imageUrl,
    required this.title,
    required this.body,
  });

  final String imageUrl;
  final String title;
  final String body;
}
