import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/router.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../data/mock/mock_data.dart';
import '../../../../data/models/product.dart';
import 'product_card.dart';

class ExploreTab extends StatefulWidget {
  const ExploreTab({super.key});

  @override
  State<ExploreTab> createState() => _ExploreTabState();
}

class _ExploreTabState extends State<ExploreTab> {
  final _query = TextEditingController();

  int _gridColumns(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    if (w >= 1100) return 4;
    if (w >= 800) return 3;
    return 2;
  }

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  List<Product> _filtered() {
    final q = _query.text.trim().toLowerCase();
    if (q.isEmpty) return MockData.products;
    return MockData.products
        .where((p) {
          return p.title.toLowerCase().contains(q) ||
              p.category.toLowerCase().contains(q) ||
              p.subtitle.toLowerCase().contains(q);
        })
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final items = _filtered();
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
          sliver: SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppConstants.exploreTitle,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _query,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    hintText: AppConstants.homeSearchHint,
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (items.isEmpty)
          SliverFillRemaining(
            hasScrollBody: false,
            child: EmptyState(
              title: AppConstants.emptySearchTitle,
              message: AppConstants.emptySearchBody,
              actionLabel: AppConstants.clearSearch,
              onAction: () {
                _query.clear();
                setState(() {});
              },
            ),
          )
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: _gridColumns(context),
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: 0.62,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final p = items[index];
                  return ProductCard(
                    product: p,
                    onTap: () => context.push(AppRouter.productDetail(p.id)),
                  );
                },
                childCount: items.length,
              ),
            ),
          ),
      ],
    );
  }
}
