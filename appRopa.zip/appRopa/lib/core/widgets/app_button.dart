import 'package:flutter/material.dart';

enum AppButtonVariant { filled, tonal, outline }

class AppButton extends StatelessWidget {
  const AppButton({
    super.key,
    required this.label,
    this.onPressed,
    this.loading = false,
    this.variant = AppButtonVariant.filled,
    this.icon,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final AppButtonVariant variant;
  final IconData? icon;

  bool get _enabled => onPressed != null && !loading;

  @override
  Widget build(BuildContext context) {
    final child = loading
        ? SizedBox(
            height: 22,
            width: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: variant == AppButtonVariant.filled
                  ? Theme.of(context).colorScheme.onPrimary
                  : Theme.of(context).colorScheme.primary,
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 20),
                const SizedBox(width: 8),
              ],
              Text(label),
            ],
          );

    switch (variant) {
      case AppButtonVariant.filled:
        return FilledButton(
          onPressed: _enabled ? onPressed : null,
          child: child,
        );
      case AppButtonVariant.tonal:
        return FilledButton.tonal(
          onPressed: _enabled ? onPressed : null,
          child: child,
        );
      case AppButtonVariant.outline:
        return OutlinedButton(
          onPressed: _enabled ? onPressed : null,
          child: child,
        );
    }
  }
}
