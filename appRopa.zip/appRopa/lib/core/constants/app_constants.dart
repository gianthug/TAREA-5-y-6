/// Cadenas y constantes de UI centralizadas (evita literales repetidos).
abstract final class AppConstants {
  AppConstants._();

  static const String appName = 'App Ropa';

  static const String onboardingTitle1 = 'Tu estilo, tu ritmo';
  static const String onboardingBody1 =
      'Descubre prendas seleccionadas y combina looks con una experiencia clara y rápida.';
  static const String onboardingTitle2 = 'Colecciones curadas';
  static const String onboardingBody2 =
      'Explora categorías, favoritos y novedades con una interfaz moderna.';
  static const String onboardingTitle3 = 'Listo para empezar';
  static const String onboardingBody3 =
      'Crea tu cuenta o inicia sesión para guardar tus piezas favoritas.';

  static const String skip = 'Saltar';
  static const String next = 'Siguiente';
  static const String getStarted = 'Comenzar';

  static const String loginTitle = 'Bienvenido de nuevo';
  static const String loginSubtitle = 'Inicia sesión para continuar';
  static const String email = 'Correo electrónico';
  static const String password = 'Contraseña';
  static const String forgotPassword = '¿Olvidaste tu contraseña?';
  static const String login = 'Iniciar sesión';
  static const String noAccount = '¿No tienes cuenta?';
  static const String register = 'Registrarse';

  static const String registerTitle = 'Crea tu cuenta';
  static const String registerSubtitle = 'Completa los datos para unirte';
  static const String fullName = 'Nombre completo';
  static const String confirmPassword = 'Confirmar contraseña';
  static const String haveAccount = '¿Ya tienes cuenta?';
  static const String signIn = 'Iniciar sesión';

  static const String homeGreeting = 'Hola';
  static const String homeSearchHint = 'Buscar prendas, marcas…';
  static const String exploreTitle = 'Explorar';
  static const String profileTitle = 'Perfil';

  static const String addToCart = 'Añadir al carrito';
  static const String description = 'Descripción';

  static const String emptySearchTitle = 'Sin resultados';
  static const String emptySearchBody =
      'Prueba con otra palabra o limpia la búsqueda.';
  static const String clearSearch = 'Limpiar';

  static const String settingsAppearance = 'Apariencia';
  static const String themeSystem = 'Sistema';
  static const String themeLight = 'Claro';
  static const String themeDark = 'Oscuro';
  static const String notifications = 'Notificaciones';
  static const String privacy = 'Privacidad';
  static const String logout = 'Cerrar sesión';

  static const String validationEmail = 'Introduce un correo válido';
  static const String validationPassword =
      'La contraseña debe tener al menos 6 caracteres';
  static const String validationName = 'Introduce tu nombre';
  static const String validationConfirm = 'Las contraseñas no coinciden';
}
