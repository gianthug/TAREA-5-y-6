import 'package:flutter/material.dart';

abstract final class AppColors {
  AppColors._();
.
  static const Color seed = Color(0xFFC45C3E);

  static const Color cream = Color(0xFFFAF8F5);
  static const Color sand = Color(0xFFF0EBE3);
  static const Color charcoal = Color(0xFF1A1A1A);
  static const Color muted = Color(0xFF6B6B6B);
  static const Color borderLight = Color(0xFFE6E0D8);
  static const Color success = Color(0xFF2E7D4A);
  static const Color error = Color(0xFFB3261E);

  static const Color overlayDark = Color(0x66000000);
}
