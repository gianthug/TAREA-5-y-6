import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';


abstract final class AppTextStyles {
  AppTextStyles._();

  static TextTheme textTheme(ColorScheme scheme) {
    final base = TextTheme(
      displayLarge: GoogleFonts.dmSans(
        fontWeight: FontWeight.w700,
        fontSize: 36,
        height: 1.1,
        color: scheme.onSurface,
      ),
      headlineMedium: GoogleFonts.dmSans(
        fontWeight: FontWeight.w700,
        fontSize: 24,
        height: 1.2,
        color: scheme.onSurface,
      ),
      titleLarge: GoogleFonts.dmSans(
        fontWeight: FontWeight.w600,
        fontSize: 20,
        height: 1.25,
        color: scheme.onSurface,
      ),
      titleMedium: GoogleFonts.dmSans(
        fontWeight: FontWeight.w600,
        fontSize: 16,
        height: 1.3,
        color: scheme.onSurface,
      ),
      bodyLarge: GoogleFonts.dmSans(
        fontWeight: FontWeight.w400,
        fontSize: 16,
        height: 1.45,
        color: scheme.onSurface,
      ),
      bodyMedium: GoogleFonts.dmSans(
        fontWeight: FontWeight.w400,
        fontSize: 14,
        height: 1.45,
        color: scheme.onSurfaceVariant,
      ),
      labelLarge: GoogleFonts.dmSans(
        fontWeight: FontWeight.w600,
        fontSize: 14,
        height: 1.2,
        letterSpacing: 0.2,
        color: scheme.onPrimary,
      ),
    );
    return base;
  }

  static TextStyle priceStyle(BuildContext context, {bool emphasize = true}) {
    final scheme = Theme.of(context).colorScheme;
    return GoogleFonts.dmSans(
      fontWeight: emphasize ? FontWeight.w700 : FontWeight.w500,
      fontSize: 18,
      color: scheme.primary,
    );
  }

  static TextStyle subtle(BuildContext context) {
    return GoogleFonts.dmSans(
      fontSize: 13,
      color: AppColors.muted,
      height: 1.35,
    );
  }
}
