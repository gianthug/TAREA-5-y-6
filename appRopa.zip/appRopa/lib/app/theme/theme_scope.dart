import 'package:flutter/material.dart';

class ThemeScope extends InheritedWidget {
  const ThemeScope({
    super.key,
    required this.themeMode,
    required super.child,
  });

  final ValueNotifier<ThemeMode> themeMode;

  static ValueNotifier<ThemeMode> of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<ThemeScope>();
    assert(scope != null, 'ThemeScope no encontrado en el árbol');
    return scope!.themeMode;
  }

  @override
  bool updateShouldNotify(ThemeScope oldWidget) =>
      oldWidget.themeMode != themeMode;
}
