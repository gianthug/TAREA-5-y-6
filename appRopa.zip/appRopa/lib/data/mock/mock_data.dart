import '../models/product.dart';
import '../models/user_profile.dart';

/// Datos locales de demostración (sin backend).
abstract final class MockData {
  MockData._();

  static const UserProfile currentUser = UserProfile(
    name: 'Alex Martínez',
    email: 'alex.martinez@ejemplo.com',
    avatarUrl:
        'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80',
  );

  static final List<String> categories = [
    'Todo',
    'Casual',
    'Formal',
    'Street',
    'Oficina',
  ];

  static final List<Product> products = [
    Product(
      id: 'p1',
      title: 'Chaqueta ligera urbana',
      subtitle: 'Capa media · Transición',
      price: 89.9,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80',
      category: 'Casual',
      description:
          'Corte contemporáneo con bolsillos funcionales. Ideal para entretiempo y desplazamientos diarios.',
    ),
    Product(
      id: 'p2',
      title: 'Set minimal workspace',
      subtitle: 'Inspiración look oficina',
      price: 49.0,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
      category: 'Oficina',
      description:
          'Estética limpia y tonos neutros. Combina con camisas básicas y calzado sobrio.',
    ),
    Product(
      id: 'p3',
      title: 'Equipo creativo',
      subtitle: 'Colaboración & diseño',
      price: 39.0,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80',
      category: 'Street',
      description:
          'Referencia de ambiente creativo para looks relajados con identidad propia.',
    ),
    Product(
      id: 'p4',
      title: 'Blazer estructurado',
      subtitle: 'Silueta definida',
      price: 129.0,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=80',
      category: 'Formal',
      description:
          'Hombros suaves y cierre minimal. Perfecto para reuniones y eventos semi-formales.',
    ),
    Product(
      id: 'p5',
      title: 'Sesión lookbook',
      subtitle: 'Editorial suave',
      price: 69.5,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1200&q=80',
      category: 'Casual',
      description:
          'Paleta cálida y texturas naturales. Combina capas ligeras y accesorios discretos.',
    ),
    Product(
      id: 'p6',
      title: 'Tejido premium',
      subtitle: 'Detalle y tacto',
      price: 74.0,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1513258496099-48168024aec0?auto=format&fit=crop&w=1200&q=80',
      category: 'Formal',
      description:
          'Acabados cuidados y caída elegante. Mantenimiento sencillo y buena duración.',
    ),
    Product(
      id: 'p7',
      title: 'Reunión de equipo',
      subtitle: 'Negocios modernos',
      price: 95.0,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80',
      category: 'Oficina',
      description:
          'Look profesional con toques contemporáneos. Funciona con pantalón chino o denim oscuro.',
    ),
    Product(
      id: 'p8',
      title: 'Mesa de estrategia',
      subtitle: 'Oficina abierta',
      price: 59.9,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800&q=80',
      category: 'Oficina',
      description:
          'Inspiración para conjuntos smart-casual con foco en comodidad y presencia.',
    ),
    Product(
      id: 'p9',
      title: 'Workshop conjunto',
      subtitle: 'Dinámica colaborativa',
      price: 45.0,
      currency: 'EUR',
      imageUrl:
          'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80',
      category: 'Street',
      description:
          'Estilo relajado con energía de equipo. Perfecto para días intensos y creativos.',
    ),
  ];

  static Product? productById(String id) {
    for (final p in products) {
      if (p.id == id) return p;
    }
    return null;
  }

  static List<Product> heroBannerImages() => products.take(4).toList();
}
