class Product {
  const Product({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.price,
    required this.currency,
    required this.imageUrl,
    required this.category,
    required this.description,
  });

  final String id;
  final String title;
  final String subtitle;
  final double price;
  final String currency;
  final String imageUrl;
  final String category;
  final String description;

  String get formattedPrice => '${price.toStringAsFixed(2)} $currency';
}
